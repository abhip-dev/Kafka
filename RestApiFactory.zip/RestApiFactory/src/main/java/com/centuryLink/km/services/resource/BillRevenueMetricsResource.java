package com.centuryLink.km.services.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.centuryLink.km.services.properties.PropertyManager;
import com.centuryLink.km.services.resource.beans.BillRevenueMetrics;
import com.centuryLink.km.services.resource.beans.Level3Response;


@Path("/Search/billRevenueMetrics")
public class BillRevenueMetricsResource extends AbstractBaseResource{
	
	@GET
    //@com.webcohesion.enunciate.metadata.rs.TypeHint(BillRevenueMetrics.class)
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response search()
    {
        //StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
        
        try
        {
            return super.doQuery(BillRevenueMetrics.class);
        }
        finally
        {
            //stopWatch.stop(uriInfo.getPath() + "-" + request.getMethod(), uriInfo.getQueryParameters().toString());
        }
    }
	
    @SuppressWarnings("unchecked")
    protected <T> Level3Response<?> getLevel3Response(List<T> resultList, long numFound, long start)
    {
        Level3Response<BillRevenueMetrics> level3Response = 
                new Level3Response<BillRevenueMetrics>(
                        (List<BillRevenueMetrics>)resultList,
                        numFound,
                        start);
        
        return level3Response;
    }
    
    protected String getSolrUrl()
    {
        return PropertyManager.instance().getProperty(PropertyManager.BILLREVENUEMETRICS_SOLR_URL_STR);
    }
	
}
