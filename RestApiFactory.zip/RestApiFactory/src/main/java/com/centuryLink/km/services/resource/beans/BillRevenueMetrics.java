package com.centuryLink.km.services.resource.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="BillRevenueMetrics")
@XmlAccessorType(XmlAccessType.FIELD)
public class BillRevenueMetrics
{
    @Field("id")
    private String id;
    @Field("countryName")
    private String countryName;
    @Field("countryFullName")
    private String countryFullName;
    @Field("country2LetterIsoCode")
    private String country2LetterIsoCode;
    @Field("country3LetterIsoCode")
    private String country3LetterIsoCode;
    @Field("countryIsoNumber")
    private String countryIsoNumber;
    @Field("internationalDialCode")
    private String internationalDialCode;

    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getCountryName()
    {
        return countryName;
    }
    public void setCountryName(String countryName)
    {
        this.countryName = countryName;
    }
    public String getCountryFullName()
    {
        return countryFullName;
    }
    public void setCountryFullName(String countryFullName)
    {
        this.countryFullName = countryFullName;
    }
    public String getCountry2LetterIsoCode()
    {
        return country2LetterIsoCode;
    }
    public void setCountry2LetterIsoCode(String country2LetterIsoCode)
    {
        this.country2LetterIsoCode = country2LetterIsoCode;
    }
    public String getCountry3LetterIsoCode()
    {
        return country3LetterIsoCode;
    }
    public void setCountry3LetterIsoCode(String country3LetterIsoCode)
    {
        this.country3LetterIsoCode = country3LetterIsoCode;
    }
    public String getCountryIsoNumber()
    {
        return countryIsoNumber;
    }
    public void setCountryIsoNumber(String countryIsoNumber)
    {
        this.countryIsoNumber = countryIsoNumber;
    }
    public String getInternationalDialCode()
    {
        return internationalDialCode;
    }
    public void setInternationalDialCode(String internationalDialCode)
    {
        this.internationalDialCode = internationalDialCode;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("BillRevenueMetrics [id=");
        builder.append(id);
        builder.append(", countryName=");
        builder.append(countryName);
        builder.append(", countryFullName=");
        builder.append(countryFullName);
        builder.append(", country2LetterIsoCode=");
        builder.append(country2LetterIsoCode);
        builder.append(", country3LetterIsoCode=");
        builder.append(country3LetterIsoCode);
        builder.append(", countryIsoNumber=");
        builder.append(countryIsoNumber);
        builder.append(", internationalDialCode=");
        builder.append(internationalDialCode);
        builder.append("]");
        return builder.toString();
    }
}