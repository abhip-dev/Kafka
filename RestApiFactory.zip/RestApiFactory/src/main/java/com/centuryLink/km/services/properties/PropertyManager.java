package com.centuryLink.km.services.properties;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyManager
{
    private static Logger log = LoggerFactory.getLogger(PropertyManager.class);
    private static PropertyManager instance = null;
    private static Object mutex = new int[ 1 ];
    
    private Properties properties = null;
    
    public static final String BILLREVENUEMETRICS_SOLR_URL_STR = "BILLREVENUEMETRICS_SOLR_URL";

    public static final String ENVIRONMENT_STR = "ENVIRONMENT";
    public static final String SOLR_CLOUD_USERNAME_STR = "SOLR_CLOUD_USERNAME";
    public static final String SOLR_CLOUD_PASSWORD_STR = "SOLR_CLOUD_PASSWD";
    public static final String CERT_STORE_PASSWORD_STR = "SOLR_CLOUD_CERT_STORE_PASSWD";
    public static final String SOLR_CLOUD_PREFIX = "SOLR_CLOUD";
    
    private PropertyManager()
    {
        try
        {
            URL url = this.getClass().getResource("/ResourceLocator.properties");

            properties = new Properties();
            properties.load(url.openStream());

            URL url2 = this.getClass().getResource("/EnvironmentSelector.properties");

            properties.load(url2.openStream());
        }
        catch(IOException ioe)
        {
            log.error("caught exception while trying to read properties file.", ioe);
        }
    }
    
    public static PropertyManager instance()
    {
        PropertyManager tempInstance = null;
        
        if(instance == null)
        {
            synchronized (mutex)
            {
                if(instance == null)
                {
                    tempInstance = new PropertyManager();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    private String getTestEnvironment()
    {
        return properties.getProperty(ENVIRONMENT_STR);
    }
    
    public String getProperty(String attribute)
    {
        if(attribute.startsWith(SOLR_CLOUD_PREFIX))
        {
            return properties.getProperty(attribute);
        }
        else
        {
            return properties.getProperty(getTestEnvironment() + "." + attribute);
        }
    }
    
	/*
	 * public static void main(String[] args) { try {
	 * log.info(PropertyManager.instance().getProperty(TNLOOKUP_SOLR_URL_STR));
	 * log.info(PropertyManager.instance().getProperty(SLV_SOLR_URL_STR));
	 * log.info(PropertyManager.instance().getProperty(TASKORDER_SOLR_URL_STR)); }
	 * catch(Exception ex) { log.error("caught exception", ex); } }
	 */
}
