package com.centuryLink.km.services.resource.beans;

import java.util.List;

import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlRootElement(name = "level3Response")
@XmlSeeAlso({
             BillRevenueMetrics.class,
            })
public class Level3Response<T>
{
    @XmlAnyElement
    protected List<T> content;

    private Long numFound;
    
    private Long start;
    
    Level3Response() 
    {
        
    }
    
    public Level3Response(List<T> content, long numFound, long start)
    {
        this.content = content;
        
        this.numFound = numFound;
        
        this.start = start;
    }

    @XmlAttribute
    public Long getNumFound()
    {
        return numFound;
    }
    public void setNumFound(Long numFound)
    {
        this.numFound = numFound;
    }
    @XmlAttribute
    public Long getStart()
    {
        return start;
    }
    public void setStart(Long start)
    {
        this.start = start;
    }
}
