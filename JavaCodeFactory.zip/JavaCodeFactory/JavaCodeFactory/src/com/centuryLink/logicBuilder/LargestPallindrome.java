package com.centuryLink.logicBuilder;

import java.util.Scanner;

public class LargestPallindrome {

	public static void main(String[] args) {
		String userInput = takeUserinput();
		String res = findLargestPallindrome(userInput);
		System.out.println("Largest Pallindrome found in " +userInput +" is: " +res);
	}

	private static String takeUserinput() {
		Scanner input = new Scanner(System.in);
		System.out.print("Please Enter a Valid String...: ");
		String userInput = input.next();
		input.close();
		return userInput;
	}

	private static String findLargestPallindrome(String input) {
        int rightIndex = 0, leftIndex = 0;
        String currentPalindrome = "", longestPalindrome = "";
        for (int centerIndex = 1; centerIndex < input.length() - 1; centerIndex++) {
            leftIndex = centerIndex - 1;  rightIndex = centerIndex + 1;
            while (leftIndex >= 0 && rightIndex < input.length()) {
                if (input.charAt(leftIndex) != input.charAt(rightIndex)) {
                	//longestPalindrome = "None";
                    break;
                }
                currentPalindrome = input.substring(leftIndex, rightIndex + 1);
                longestPalindrome = currentPalindrome.length() > longestPalindrome.length() ? currentPalindrome : longestPalindrome;
                leftIndex--;  rightIndex++;
            }
        }
        return longestPalindrome;
	}

}