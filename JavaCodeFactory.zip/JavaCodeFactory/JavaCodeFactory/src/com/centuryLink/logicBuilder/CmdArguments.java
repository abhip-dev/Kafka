package com.centuryLink.logicBuilder;

public class CmdArguments {
	public static void main(String[] args) {

		if (args.length > 0) {
			System.out.println("The command line" + " arguments are:");
			// for (String val:args)
			// System.out.println(val);
			for (int i = 0; i < args.length; i++) {
				int result = Integer.parseInt(args[i]);
				System.out.println("int: " + result + ", string: " + args[i]);
			}
		} else {
			System.out.println("No command line " + "arguments found.");

		}
	}
}