package com.centuryLink.logicBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class ClientCaller {

	public static void main(String[] args) throws IOException {
		URL url = new URL("http://kmservices.level3.com/DataServices/v1/Search/loopQualification?fq=tnNumber:9702402145%20OR%20tnNumber:6238731471&q=*:*");
        URLConnection urlConn = url.openConnection();
        InputStreamReader inStream = new InputStreamReader(urlConn.getInputStream());
        BufferedReader buff = new BufferedReader(inStream);
        StringBuilder builder = new StringBuilder();
        String line = buff.readLine();
        System.out.println("--------->>" +line);
        while (line !=null){
        	builder.append(line).append(System.lineSeparator());
		    line = buff.readLine();
        }
        	System.out.println("Result is: "+builder.toString());
	}
}