package com.centurylink.hyperlite.event;

import java.util.List;
import java.io.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.avro.io.DatumReader;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.specific.SpecificDatumReader;

public class DataParser {
	public static void Deserialize() throws IOException {      
				
		File opfile = new File("output.txt");
		if (opfile.exists()) {
			opfile.delete();
		}
		
		String fileName = "hce.1567516155837.avro";
		ClassLoader classLoader = ClassLoader.getSystemClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());
		
		PrintWriter printwrite = new PrintWriter(new FileWriter("output.txt", true), true);
		
		DatumReader<HealthCertificateEvent> user = new SpecificDatumReader<HealthCertificateEvent>(HealthCertificateEvent.class);
		DataFileReader<HealthCertificateEvent> dataFileReader = null;
		HealthCertificateEvent metadata = null;
		try {
			dataFileReader = new DataFileReader<HealthCertificateEvent>(file, user);        
			while (dataFileReader.hasNext()) {
				metadata = dataFileReader.next(metadata);				
				//System.out.println(metadata.getActualDnSpeed());
				System.out.println(metadata.getEventId());

				//List<Data> list = new ArrayList<Data>();				
				//list = metadata.getRecordCollection();
				//list = metadata.getActualDnSpeed();
				//System.out.println(myDat
				
				/*
				 * for (int i=0; i<list.size(); i++) { EngagementData myData = (EngagementData)
				 * list.get(i).getBody();
				 * 
				 * System.out.println(myData.getHeader()); printwrite.write(myData.toString());
				 * printwrite.write("\n"); }
				 */
								
				//printwrite.write(metadata.getRecordCollection().toString());
				//printwrite.write("\n");
			}
			printwrite.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
	Deserialize();
	}
}