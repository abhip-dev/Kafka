package com.centuryLink.kafkastreamingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamingAppApplication.class, args);
	}

}
