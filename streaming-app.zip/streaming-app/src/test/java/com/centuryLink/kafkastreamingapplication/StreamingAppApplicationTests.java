package com.centuryLink.kafkastreamingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
